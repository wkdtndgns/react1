import React, { Component } from 'react';

class Cpp extends Component {
    render() {
      return (
        <div>
          <h1>Cpp</h1>
          <h1>{this.props.num}</h1>
        </div>
      );
    }
  }

export default Cpp;
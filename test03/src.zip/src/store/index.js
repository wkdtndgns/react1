import ts from './tigerStore';
import ls from './lionStroe';
import postStore from './PostStore';

const totalStore = {ts, ls, postStore}

export default totalStore;
import { makeAutoObservable } from "mobx";
import axios from "axios";

class PostStore {
    post = [];

    constructor() {
        makeAutoObservable(this)
    }
    fetchPost(id) {
      axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`)
           .then(response => {
            this.post.push(response.data)
            })
            .catch(error => {
                console.error("Error fetching post:", error);
            });
    }
}

export default new PostStore();

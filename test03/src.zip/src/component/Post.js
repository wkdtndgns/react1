import React, { useEffect,useState } from 'react';
import { observer } from 'mobx-react';
import totalStore from '../store';

const Post = observer(() => {
    const [id, setId] = useState('');
    const fetchPost = () => {
        console.log(postStore.post);
        postStore.fetchPost(id);
    };

    const postStore = totalStore.postStore;

    useEffect(() => {
        postStore.fetchPost(1);
    }, []);

    return (
        <div>
          <input type="number" value={id} onChange={e => setId(e.target.value)} />
            <button onClick={fetchPost}>Fetch Post</button>
        </div>
    );
});

export default Post;

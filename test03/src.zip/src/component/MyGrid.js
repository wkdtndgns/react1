import React, { useRef, useEffect } from 'react';
import Grid from 'tui-grid';

import 'tui-grid/dist/tui-grid.css';
import 'tui-date-picker/dist/tui-date-picker.css';
import 'tui-pagination/dist/tui-pagination.css';

Grid.applyTheme('striped');

function MyGrid({ data, columns }) {
    const gridEl = useRef(null);

    useEffect(() => {
        new Grid({
            el: gridEl.current,
            data,
            columns
        });
    }, [data, columns]);

    return <div ref={gridEl} />;
}

export default MyGrid;
